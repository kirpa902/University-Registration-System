Project developed in IntelliJ IDEA.
Open project folder in IntelliJ and run main class.
Database required: university_db (see attached SQL file).